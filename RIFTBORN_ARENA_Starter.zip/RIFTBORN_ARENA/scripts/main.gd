extends Node3D

var player: CharacterBody3D
var camera: Camera3D
var move_speed := 6.0
var arena_size := 28.0

func _ready() -> void:
    _make_arena()
    _make_player()
    _make_camera()
    _make_lighting()
    _make_label()

func _make_arena() -> void:
    var floor := MeshInstance3D.new()
    var floor_mesh := PlaneMesh.new()
    floor_mesh.size = Vector2(arena_size, arena_size)
    floor.mesh = floor_mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.12, 0.25, 0.20)
    mat.roughness = 1.0
    floor.material_override = mat
    add_child(floor)

    var grid := MeshInstance3D.new()
    var grid_mesh := PlaneMesh.new()
    grid_mesh.size = Vector2(arena_size, arena_size)
    grid.mesh = grid_mesh
    var grid_mat := StandardMaterial3D.new()
    grid_mat.albedo_color = Color(0.17, 0.32, 0.27)
    grid_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    grid_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    grid_mat.albedo_color.a = 0.22
    grid.material_override = grid_mat
    grid.position.y = 0.015
    add_child(grid)

    _make_boundary(Vector3(0, 0.5, -arena_size / 2), Vector3(arena_size, 1, 0.5))
    _make_boundary(Vector3(0, 0.5, arena_size / 2), Vector3(arena_size, 1, 0.5))
    _make_boundary(Vector3(-arena_size / 2, 0.5, 0), Vector3(0.5, 1, arena_size))
    _make_boundary(Vector3(arena_size / 2, 0.5, 0), Vector3(0.5, 1, arena_size))

func _make_boundary(pos: Vector3, size: Vector3) -> void:
    var wall := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    wall.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.16, 0.19, 0.28)
    wall.material_override = mat
    wall.position = pos
    add_child(wall)

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.name = "OBY_GM_Player"
    player.position = Vector3(0, 1, 5)
    add_child(player)

    var body := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.8
    body.mesh = capsule
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.15, 0.65, 0.95)
    mat.metallic = 0.25
    body.material_override = mat
    player.add_child(body)

    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.48
    shape.height = 1.8
    collision.shape = shape
    player.add_child(collision)

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.name = "ArenaCamera"
    add_child(camera)
    camera.position = Vector3(0, 16, 18)
    camera.rotation_degrees = Vector3(-42, 0, 0)
    camera.current = true

func _make_lighting() -> void:
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)

func _make_label() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var label := Label.new()
    label.text = "RIFTBORN: ARENA  |  Prototype 3D\nGerakkan OBY GM dengan WASD / tombol arah."
    label.position = Vector2(18, 18)
    label.add_theme_font_size_override("font_size", 18)
    layer.add_child(label)

func _physics_process(_delta: float) -> void:
    if player == null:
        return
    var input := Vector2.ZERO
    input.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
    input.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
    var direction := Vector3(input.x, 0, input.y).normalized()
    player.velocity.x = direction.x * move_speed
    player.velocity.z = direction.z * move_speed
    player.velocity.y = 0
    player.move_and_slide()
    if direction.length() > 0.01:
        player.rotation.y = atan2(direction.x, direction.z)
