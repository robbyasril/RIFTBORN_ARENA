RIFTBORN: ARENA - PROTOTIPE AWAL

Cara membuka:
1. Ekstrak ZIP ini ke folder di HP.
2. Buka Godot Android Editor.
3. Dari daftar proyek, pilih Impor / Import.
4. Cari folder hasil ekstrak, lalu pilih file project.godot.
5. Buka proyek tersebut.
6. Tekan tombol Jalankan (ikon segitiga/play).

Isi prototipe:
- Arena 3D sederhana
- Kamera sudut isometrik
- Karakter placeholder OBY GM
- Gerakan dasar memakai tombol arah / input ui di editor

Catatan:
Ini fondasi awal, belum game MOBA lengkap dan belum memiliki joystick sentuh, bot, skill, tower, atau sistem 5v5.
