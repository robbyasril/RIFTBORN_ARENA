extends Node3D

var player: CharacterBody3D
var touching := false
var touch_start := Vector2.ZERO
var touch_vector := Vector2.ZERO

func _ready():
    var floor = MeshInstance3D.new()
    var plane = PlaneMesh.new()
    plane.size = Vector2(30, 30)
    floor.mesh = plane
    var fm = StandardMaterial3D.new()
    fm.albedo_color = Color(0.10, 0.24, 0.18)
    floor.material_override = fm
    add_child(floor)

    for i in range(-14, 15, 2):
        add_box(Vector3(i, 0.03, 0), Vector3(0.025, 0.02, 30), Color(0.25,0.4,0.3))
        add_box(Vector3(0, 0.03, i), Vector3(30, 0.02, 0.025), Color(0.25,0.4,0.3))

    add_box(Vector3(0,0.5,-15), Vector3(30,1,0.5), Color(0.15,0.18,0.25))
    add_box(Vector3(0,0.5,15), Vector3(30,1,0.5), Color(0.15,0.18,0.25))
    add_box(Vector3(-15,0.5,0), Vector3(0.5,1,30), Color(0.15,0.18,0.25))
    add_box(Vector3(15,0.5,0), Vector3(0.5,1,30), Color(0.15,0.18,0.25))

    player = CharacterBody3D.new()
    player.name = "OBY_GM"
    player.position = Vector3(0,1,5)
    add_child(player)
    var body = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.8
    body.mesh = capsule
    var bm = StandardMaterial3D.new()
    bm.albedo_color = Color(0.12,0.58,0.95)
    body.material_override = bm
    player.add_child(body)
    var col = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    shape.radius = 0.48
    shape.height = 1.8
    col.shape = shape
    player.add_child(col)

    var cam = Camera3D.new()
    cam.position = Vector3(0,17,19)
    cam.rotation_degrees = Vector3(-42,0,0)
    cam.current = true
    add_child(cam)
    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55,-25,0)
    add_child(sun)

    var ui = CanvasLayer.new()
    add_child(ui)
    var label = Label.new()
    label.text = "RIFTBORN: ARENA\nOBY GM - Prototype 3D"
    label.position = Vector2(18,18)
    label.add_theme_font_size_override("font_size",22)
    ui.add_child(label)
    var help = Label.new()
    help.text = "Sentuh dan geser sisi kiri layar untuk bergerak"
    help.position = Vector2(18,76)
    ui.add_child(help)

func add_box(pos: Vector3, size: Vector3, color: Color):
    var m = MeshInstance3D.new()
    var b = BoxMesh.new()
    b.size = size
    m.mesh = b
    var mat = StandardMaterial3D.new()
    mat.albedo_color = color
    m.material_override = mat
    m.position = pos
    add_child(m)

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed and event.position.x < get_viewport().get_visible_rect().size.x * 0.55:
            touching = true
            touch_start = event.position
            touch_vector = Vector2.ZERO
        elif not event.pressed:
            touching = false
            touch_vector = Vector2.ZERO
    elif event is InputEventScreenDrag and touching:
        touch_vector = (event.position - touch_start).limit_length(90) / 90.0

func _physics_process(_delta):
    if player == null:
        return
    var v = Vector2.ZERO
    v.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
    v.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
    if touching:
        v = touch_vector
    var d = Vector3(v.x,0,v.y).normalized()
    player.velocity = Vector3(d.x*6.0,0,d.z*6.0)
    player.move_and_slide()
    if d.length() > 0.01:
        player.rotation.y = atan2(d.x,d.z)
